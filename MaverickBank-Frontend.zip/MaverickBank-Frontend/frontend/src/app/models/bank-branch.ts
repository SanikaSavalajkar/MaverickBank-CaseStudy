export interface BankBranch {
  branchId: number;
  name: string;
  address: string;
  ifscPrefix: string;
}
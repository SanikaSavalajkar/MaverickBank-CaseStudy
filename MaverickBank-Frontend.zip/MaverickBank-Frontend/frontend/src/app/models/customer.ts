export interface Customer {
  customerId?: number;
  userId?: number;
  name: string;
  gender: string;
  contactNumber: string;
  address: string;
  dateOfBirth: string;  
  aadharNumber: string;
  panNumber: string;
}
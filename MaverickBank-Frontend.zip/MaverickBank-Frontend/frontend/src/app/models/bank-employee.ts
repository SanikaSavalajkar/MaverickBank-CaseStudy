export interface BankEmployee {
    userId: number;
  name: string;
  contactNumber: string;
  branchId: number;
  employeeId?: string;
}
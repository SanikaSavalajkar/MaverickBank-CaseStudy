package com.hexaware.maverickBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.security.SecurityScheme;

@OpenAPIDefinition(
		security = { @SecurityRequirement(name = "bearerAuth") } // ✅ use array
)

@SecurityScheme(
		name = "bearerAuth",
	    type = SecuritySchemeType.HTTP,
	    scheme = "bearer",
	    bearerFormat = "JWT"
)

@SpringBootApplication
public class MaverickBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(MaverickBankApplication.class, args);
		System.out.println("Maverick Bank Application is Working........");
	}

}

package com.hexaware.maverickBank.controller;

import com.hexaware.maverickBank.dto.LoginRequestDTO;
import com.hexaware.maverickBank.dto.LoginResponseDTO;
import com.hexaware.maverickBank.dto.UserDTO;
import com.hexaware.maverickBank.dto.UserRegistrationRequestDTO;
import com.hexaware.maverickBank.service.interfaces.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UserService userService;

    // ✅ Registration endpoint (open access)
    @PostMapping("/register")
    public UserDTO registerUser(@RequestBody UserRegistrationRequestDTO dto) {
        return userService.registerUser(dto);
    }

    // ✅ Login endpoint (returns token + user info)
    @PostMapping("/login")
    public LoginResponseDTO login(@RequestBody LoginRequestDTO dto) {
        return userService.login(dto.getUsername(), dto.getPassword());
    }
}

package com.hexaware.maverickBank.dto;

//import src.main.java.com.hexaware.maverickBank.dto.Long;
//import src.main.java.com.hexaware.maverickBank.dto.String;

public class LoginResponseDTO {
	
	private Long userId;
    private String username;
    private Long roleId;
    private String roleName;
    private String token;
    
	public LoginResponseDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public LoginResponseDTO(Long userId, String username, Long roleId, String roleName, String token) {
		super();
		this.userId = userId;
		this.username = username;
		this.roleId = roleId;
		this.roleName = roleName;
		this.token = token;
	}



	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public String getRoleName() {
		return roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}
	
}

package com.hexaware.maverickBank.dto;

//import src.main.java.com.hexaware.maverickBank.dto.Long;
//import src.main.java.com.hexaware.maverickBank.dto.String;

public class RoleDTO {

    private Long roleId;
    private String roleName;
    
	public RoleDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public RoleDTO(Long roleId, String roleName) {
		super();
		this.roleId = roleId;
		this.roleName = roleName;
	}
	
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	
}

package com.hexaware.maverickBank;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.hexaware.maverickBank.controller.BankEmployeeController;
import com.hexaware.maverickBank.dto.BankEmployeeCreateRequestDTO;
import com.hexaware.maverickBank.dto.BankEmployeeDTO;
import com.hexaware.maverickBank.service.interfaces.BankEmployeeService;

public class BankEmployeeControllerTest {

    @InjectMocks
    private BankEmployeeController controller;

    @Mock
    private BankEmployeeService service;

    private BankEmployeeDTO mockDto;
    private BankEmployeeCreateRequestDTO createDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        // Mock input DTO
        createDto = new BankEmployeeCreateRequestDTO();
        createDto.setName("Mruganka");
        createDto.setContactNumber("9876543210");
        createDto.setUserId(1L);
        createDto.setBranchId(101L);

        // Mock output DTO
        mockDto = new BankEmployeeDTO();
        mockDto.setEmployeeId(1L);
        mockDto.setName("Mruganka");
        mockDto.setContactNumber("9876543210");
    }

    @Test
    void testCreateBankEmployee() {
        when(service.createBankEmployee(any(BankEmployeeCreateRequestDTO.class))).thenReturn(mockDto);

        ResponseEntity<BankEmployeeDTO> response = controller.createBankEmployee(createDto);

        assertEquals(201, response.getStatusCodeValue());
        assertNotNull(response.getBody());
        assertEquals("Mruganka", response.getBody().getName());
    }

    @Test
    void testGetAllBankEmployees() {
        when(service.getAllBankEmployees()).thenReturn(List.of(mockDto));

        ResponseEntity<List<BankEmployeeDTO>> response = controller.getAllBankEmployees();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals("Mruganka", response.getBody().get(0).getName());
    }
}

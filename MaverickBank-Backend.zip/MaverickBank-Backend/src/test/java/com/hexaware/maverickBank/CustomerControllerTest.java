package com.hexaware.maverickBank;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.any;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import com.hexaware.maverickBank.controller.CustomerController;
import com.hexaware.maverickBank.dto.CustomerCreateRequestDTO;
import com.hexaware.maverickBank.dto.CustomerDTO;
import com.hexaware.maverickBank.service.interfaces.CustomerServcie;

class CustomerControllerTest {

	@InjectMocks
    private CustomerController controller;

    @Mock
    private CustomerServcie service;

    private CustomerDTO customerDto;
    private CustomerCreateRequestDTO createDto;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        createDto = new CustomerCreateRequestDTO();
        createDto.setName("Mruganka");
        createDto.setContactNumber("9998887776");
        createDto.setUserId(5L);

        customerDto = new CustomerDTO();
        customerDto.setCustomerId(1L);
        customerDto.setName("Mruganka");
    }

    @Test
    void testCreateCustomer() {
        when(service.createCustomer(any(CustomerCreateRequestDTO.class))).thenReturn(customerDto);

        ResponseEntity<CustomerDTO> response = controller.createCustomer(createDto);

        assertEquals(201, response.getStatusCodeValue());
        assertEquals("Mruganka", response.getBody().getName());
    }

    @Test
    void testGetAllCustomers() {
        when(service.getAllCustomers()).thenReturn(List.of(customerDto));

        ResponseEntity<List<CustomerDTO>> response = controller.getAllCustomers();

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(1, response.getBody().size());
        assertEquals("Mruganka", response.getBody().get(0).getName());
    }
}